<?php

define("DB_SERVER", "127.0.0.1");
define("DB_USER", "webuser");
define("DB_PASS", "mypass");
define("DB_NAME", "italaheb");

?>
